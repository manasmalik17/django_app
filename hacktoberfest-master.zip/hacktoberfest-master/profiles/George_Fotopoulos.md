# George Fotopoulos

### Academics

University of Patras.

### Interests

- Software Development.
- Game Development.

### Projects

- [forest](https://github.com/xorz57/forest) Forest is an open source, template library of tree data structures written in C++11.

### Profile Link

[George Fotopoulos](https://github.com/xorz57)
