# José Fernandes

### Interests

- Programming, cooking.

### Development

- Computer Science student at Univesidade Federal de Alfenas - Brazil

### Projects

- [Algoritmos](https://github.com/Josefernandes19/algoritmos) Guide to first-time programmers, based in C.

### Profile Link

[José Fernandes](https://github.com/Josefernandes19)