# Elijah (Raptosaur)

### Location

Swansea, Wales, UK

### Academics

MEng Computing, Swansea University (student)

### Development

I like creating PHP and Java projects from scratch in my own time.

### Projects

I love working on cool automation projects that can make my life easier.

### Profile Link

# [Check out my Github page](https://github.com/raptosaur)
