# Xavier Marques

## About me:

23 years old and last year CS Engineering student from Catalonia. I love hackathons because I learned a lot of things.  

## Certificates:
- Java Android developer - JEDI

## Languages that I know:

- HTML
- CSS
- JS
- Java
- C++
- Mysql
- Bash

## Frameworks and Technologies that I know:

- Bootstrap
- jQuery
- React
- Node.js
- Express
- Mongoose
- MongoDB
- Oculus rift
- Android
- Eclipse

[Check out my GitHub](https://github.com/wolframtheta)

Email me: xaviermarques4f@gmail.com
