# Mathias Pihl

### Location

Aalborg, Denmark

### Academics

5th semester Software Engineering undergrad. Expected grad: June'18

### Interests

- Big data
- Machine Learning
- Robotics

### Projects

- See my profile below

### Profile Link

[Newspaperman57](https://github.com/newspaperman57)
