# Italo Góis

### Location

Aracaju, Sergipe, Brazil

### Academics

FANESE - Faculdade de Administração e Negócios de Sergipe

### Interests

- Networking
- User experience

### Development

- website
- softwares

### Profile Link

[Italo Góis](https://github.com/italogois)
