# Rafael Barbosa Conceição

### Location

Aracaju, Sergipe, Brazil

### Academics

UFS - Universidade Federal de Sergipe

### Interests

- Open Source, Programming, IA

### Development

- Website

### Profile Link

[Rafael Barbosa Conceição](https://github.com/darthmasters/)
