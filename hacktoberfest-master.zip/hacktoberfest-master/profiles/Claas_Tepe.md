# Claas Tepe

### Location

Braunschweig, Deutschland

### Academics

Technische Universität Braunschweig

### Interests

- Games
- Sports

### Development

- A java based RPG

### Profile Link

[Claas Tepe ](https://github.com/G4dh4r)
