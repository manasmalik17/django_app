# Jason Green

### Location

Seattle, WA USA

### Academics

AAS Cascadia Community College (Bothell, WA)

### Interests

- Distilling useful information from **data**
- Sushi
- Pho
- Pork Belly
- Hiking

### Development

- Future data scientist, database engineer

### Projects

- [freeCodeCamp](https://www.freecodecamp.org/jalence) 

### Profile Link

[Jason Green](https://github.com/Jalence)