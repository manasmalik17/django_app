# Moisés Ñañez

### Location

Ica, Perú

### Academics

San Luis Gonzaga de Ica Universiy

### Interests

- GraphQL.
- React.
- Machine Learning.

### Development

- JavaScript
- HTML/CSS
- Ruby on Rails
- Electron
- React / React Native

### Projects

- V-Space desktop and web app

### Profile Link

[Moisés Ñañez](https://github.com/moisesnandres)
