# Ipaye ALameen

### Location

Ikoyi, Lagos State, Fedral Republic of Nigeria.

### Academics

University of Lagos, Nigeria.

### Interests

- Video Games
- Programming
- Music
- Movies
- Photography
- Design

### Development

- GDG manager Unilag

### Projects

- [Simon Game](https://github.com/ipaye) You can check my github to find anything you like.

### Profile Link

[Ipaye](https://github.com/ipaye)