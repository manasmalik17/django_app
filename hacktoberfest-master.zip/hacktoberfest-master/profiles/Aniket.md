# Aniket

### Location

New Delhi, India

### Academics

University of Technology and Management, Shillong

### Interests

- Cloud Computing
- Artificial Intelligence
- Open Source
- Movies
- Travelling

### Development

- AWS developer
- Data Science

### Profile Link

[Aniket](https://github.com/aniketroy)
