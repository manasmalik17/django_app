# Amit Chambial

### Location

Punjab, India

### Academics

National Institute of Technology, Hamirpur

### Interests

- Watching animes.
- Watching movies.
- Learning new things .

### Development

- Full Stack Development.
- Some competitive coding.

### Projects

- Blog SpaceSword.
- Java Game 8 queen.

### Profile Link

[Amit Chambial](https://github.com/devaman)