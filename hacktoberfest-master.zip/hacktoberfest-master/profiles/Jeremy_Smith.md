# Jeremy Smith

### Location

[Raleigh, North Carolina, USA](https://www.raleighnc.gov/)

### Academics

[University of Richmond](https://www.richmond.edu/)

### Interests

- [Maps](https://www.vox.com/2015/2/17/7917165/maps-that-explain-america)
- [Football](http://us.soccerway.com/)
- [Die deutsche Sprache](https://dict.leo.org/german-english/)
- [Film](https://www.filmspotting.net/)
- [Running](https://runologieraleigh.com/)
- [Trivia](https://www.sporcle.com/)
- [Tunes](https://youtu.be/B8Fbw9Oj2Ww)
- [More Tunes](https://youtu.be/ETkzK9pXMio?t=5s)

### Projects

- [Mapstery](https://github.com/silentDjay/Mapstery) A geography game for those who like a challenge

### Profile Link

[silentDjay](https://github.com/silentDjay)