# Grace Bell

### Location

Boone, North Carolina, USA

### Academics

Appalachian State University. Skillcrush, FreeCodeCamp

### Interests

- Coding, UX/UI Design, Hiking with my dogs, Gardening, Reading

### Development

- HTML
- CSS
- WordPress

### Projects

https://codepen.io/bellgrace/

### Profile Link

[lulabell](https://github.com/lulabell)
