# Joy Kaufman
### Location

Raleigh NC

### Academics

Business Administration UMUC for Undergrad, going back for Computer Science currently~! :)

### Interests

- Taking my dog on adventures, traveling, learning new programming languages, enormous book nerd, interested in blockchain, AI, 
and whatever else folks are panicking about 'coming for our jobs'

### Development

- I work primarily in SQL, ASP.Net & C#, JavaScript and frameworks et al, and I love me some Ruby. Trying to learn Python as a form of
methadone

### Profile Link

[Joy Kaufman](https://github.com/jtkaufman737/)
