# Jonathan De Leon

### Location

Walla Walla, WA, USA

### Academics

Walla Walla University

### Interests

- Software Engineering
- Full Stack Software Development
- Video Games (Halo, Gears of War, Overwatch

### Development

- Front-end apps with React, Vue, and AngularJS
- Back-end apps with Node, Groovy & Grails, Java, and Python
- System Administration


### Profile Link

[Jonathan De Leon](https://github.com/JonathanDeLeon)
