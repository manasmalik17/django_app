# Vishal Koosuri

### Location

New York City, NY, USA

### Academics

Master's in Computer Science(Software Development) from Marist College

### Interests

- User Interface and User Experience in Web and Mobile
- Familiar with Java, Python
- Javascript-Based Technologies
- Node, Express, Angular, Firebase, MongoDb

### Development

- Frontend UI Developer, Fullstack Software Developer, Java Developer, Web Developer

### Projects

- [AES 128-bit Keys Generator](https://github.com/dainvinc/generating-128bit-keys-using-aes-encryption)
- [My Personal Blog](https://github.com/dainvinc/dainvinc.github.io)

### Profile Link

[Vishal Koosuri](https://github.com/dainvinc)