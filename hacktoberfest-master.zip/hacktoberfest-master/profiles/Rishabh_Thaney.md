# Your Name
Rishabh Thaney

### Location

New Delhi, India 

### Academics

Bharati Vidyapeeth, New Delhi

### Interests

- Traveling, photography, reading, guitar

### Development

- GSOC '17 participant, InOut 4.0 blockchain track winner

### Projects

- [Sugar on Raspberry Pi](https://github.com/Rishabh42/rpi23-gen-image) My GSOC project

### Profile Link

[Rishbh Thaney](https://github.com/Rishabh42)
