# Alex Blum

### Location

Germany Marburg

### Academics

4 Semester Hight School

### Interests

- My Garden and Computer stuff

### Development

- My Smart Garden

### Projects

- comming soon...

### Profile Link

[Alex Blum](https://github.com/alexblum)