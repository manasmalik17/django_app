# Nethmi Wijesinghe

### Location

Kiribathgoda, Sri Lanka

### Academics

University of Moratuwa

### Interests

- Computer stuff and Reading Books

### Languages that I know

- Java
-Html
-Css
-Java Script

### Profile Link

[Nethmi96](https://github.com/Nethmi96)
