# Ginanjar S.B

### Location

Samarinda/Indonesia

### Academics

Samarinda State Polytechnic

### Interests

- Wall Climbing
- Web Devlopment / Programming
- Games
- Movies

### Development

- Backend Developer

### Profile Link

[Ginanjar S.B | egin10](https://github.com/egin10)
