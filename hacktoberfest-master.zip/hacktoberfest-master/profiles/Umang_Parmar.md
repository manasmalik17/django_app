# Umang Parmar

### Location

Gujarat, India

### Academics

Undergraduate in Information and Communication Technology

### Interests

- Operating Systems
- Networking
- Sockets
- User Interface and User Experience
- Memes

### Development

- Android Developer

### Profile Link

[Umang Parmar](https://github.com/darkLord19)
