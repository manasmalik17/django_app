# Your Name
    Gowtham.R
### Location
    Chennai

### Academics
    Svvv

### Interests
- Data Science
- Web Development

### Development

- Tic Tac Toe AI using Reinforcement learning

### Projects

- [YelpCamp](https://github.com/gowtham1997/YelpCamp) This is a REST api based campsite review web application coded with Express,Nodejs,Mongodb, passportjs(For User authentication) and hosted using Heroku

### Profile Link

[Gowtham](https://github.com/gowtham1997)
