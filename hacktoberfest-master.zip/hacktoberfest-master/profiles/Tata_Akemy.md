# Taina Akemy

### Location

Presidente Prudente, Brazil.

## About me:

Student of UNESP, Brazil.

### Projects

- Not yet

### Profile Link

[tataakemy] (https://github.com/tataakemy)
