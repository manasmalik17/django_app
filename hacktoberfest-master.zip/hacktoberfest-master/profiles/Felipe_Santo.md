# Felipe Do E. Santo

### Location

Jaboticabal, SP, Brazil

### Academics

Graduated in Data Processing and have graduate studies in IT Governance and Management

### Interests

- HTML
- CSS
- JS
- WebVR
- Education
- Games!

### Projects

- [Open Graduation Classes](https://github.com/felipez3r0/openclasses)


### Profile Link

[Felipez3r0](https://github.com/felipez3r0)