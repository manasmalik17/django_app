## Ankit Rai
a high functioning geek, et cetera!
![hey, it's Ankit!](https://pbs.twimg.com/profile_images/903953844542988288/XqKVmDxA_400x400.jpg)

#### Get-in-Touch
- web : [Ankit Rai](http://ankitrai.xyz)
- mail: [abc@ankitrai.xyz](mailto:abc@ankitrai.xyz)

#### Projects
- [Power-Pi](https://github.com/ankitrai96/power-pi)
- [multilingual Algorithm Vault](https://github.com/ankitrai96/multilingual-algorithm-vault)
- [more on my GitHub ;)](https://github.com/ankitrai96/)

#### Personal Details
- Sex    : Male
- Weight : 75 Kgs
- Height : 172 cms
- DoB    : 1st December 1996
- Age    : 20 Years

#### Geeky Interests
1. DIY Electronics (like Arduino, RaspberryPi, NodeMCU, etc.)
2. Front-End Web (like JS, HTML and tad bit CSS)
3. Mobile Stuff (React-Native)
4. Competitive Programming in C and Python

#### Social Media Handles
- Twitter [ankitRai96](https://twitter.com/ankitrai96)
- Instagram [ankitRai96](https://instagram.com/ankitrai96)
- Google+ [+ankitRai96](https://plus.google.com/+AnkitRai96)
- LinkedIn [raiAnkit96](https://www.linkedin.com/in/raiankit96)
- Facebook [ankit.digital](https://facebook.com/ankit.digital)