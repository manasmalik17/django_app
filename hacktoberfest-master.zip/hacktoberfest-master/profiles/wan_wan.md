# Wan Wan

---

### Location

Taipei, Taiwan

### Hello

Hi all, this is Wan Wan, a front-end developer. I like vanilla JS, which makes me easy to face problem from any JS codes built by library or framework. Except to programming, what I interested in is doodling. I like creating and making things come true.

### GitHub

Though I'm pretty new to github, you can still click [**here**](https://github.com/lf2com) to see my profile.