# Lukas A

### Location

Kassel, Hesse, Germany

### Academics

Currently attending to a Gymnasium (like a High School)

### Interests

- Programming
- Space

### Development

- Java
- PHP (Laravel & Symfony)
- Wants to learn Phoenix (& Elixir)
- Open for new technologies

### Projects

- [HasteIt](https://github.com/LukWebsForge/HasteIt) A plugin for IDEA-based IDEs. It can upload the file you currently working on to Hastebin
- [TwitchChat](https://github.com/LukWebsForge/TwitchChat) A Java library for interacting the with the chat of streams on Twitch.

### Profile Link

[LukBukkit](https://github.com/lukbukkit)