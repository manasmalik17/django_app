# Fran Romero

### Location

Granada, Spain

### Academics

- University of Granada

### Interests

- Open Source Software
- Open Hardware Projects

### Development

- Junior Hardware Engineer

### Projects

- [Round Squeare Labs site] (https://github.com/FranRomeroMal/roundsquarelabsWebSite) Web site of my new compnay.

### Profile Link

[Fran Romero] (https://github.com/FranRomeroMal)
