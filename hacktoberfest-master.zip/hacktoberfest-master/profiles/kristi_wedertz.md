# Kristi Wedertz

### Location

LOS ANGELES

### Academics

CALIFORNIA STATE UNIVERSITY, NORTHRIDGE

### Interests

- NERD THINGS!

### Profile Link

[kristiwedertz](https://github.com/kristiwedertz)
