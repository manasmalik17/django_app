# Sourav Verma

### Academics

- ABV-IIITM, Gwalior

### Interests

- Open Source Software
- Machine Learning
- Data Science
- Data Structures & Algorithms

### Development

- Inventor of the My Pillow

### Projects

- [cric_score](https://github.com/SrGrace/cric_score) Live Cricket Scores form Cricbuzz 

### Profile Link
[Sourav Verma] (https://github.com/SrGrace)
