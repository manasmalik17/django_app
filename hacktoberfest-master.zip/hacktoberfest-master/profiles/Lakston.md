# Lakston

### Interests

- Photography
- Calisthenics

### Development

- Angular
- React

### Projects

- [Photography portfolio](https://github.com/Lakston/Lakston) Photography portfolio developped with React and MobX.

### Profile Link

[Lakston](https://github.com/Lakston)
