# Ahmad Thames

### Location

Houston, TX, USA

### Academics

Tech Talent South- Code Immersion Fall 2017

### Interests

- Plant Based Foodie
- Traveler
- Reading
- All Things Superman

### Development

- Still in development...

### Website

[Ahmad Thames](http://ahmadthames.com)