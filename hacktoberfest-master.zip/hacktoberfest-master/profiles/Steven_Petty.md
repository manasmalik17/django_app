# Steven Petty

### Dallas/Texas

### Hacking and learning
