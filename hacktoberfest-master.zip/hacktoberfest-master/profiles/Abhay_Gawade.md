# Your Name
Manas Malik

### Location

Bangalore, India 

### Academics
Jain University, Bangalore

### Interests

-Reading, Football, Running

### Development

- Framework For Lossless Data Compression Using Python
- Fake News Detection
- Amazon Ec2 Spot Instance Forecasting

### Projects

- [Fake News Detection](https://github.com/manasmalik17/Fake_News_detection) Detection of fake news from crowdsourcing platforms.

### Profile Link

[Manas Malik](https://github.com/manasmalik17)