# Luis Alducin

:alien: Luis Daniel Alducin

### Location

:globe_with_meridians: Mexico City

### Academics

:ok_hand: Computational Systems Engineer at ESCOM, IPN

### Interests

- :pencil2: Open Source
- :pencil2: Software Architecture
- :pencil2: VR

### Profile Link

:rotating_light: [luisalduucin](https://github.com/luisalduucin/)
