# Adriano Lemos

### Location

Brasília, Distrito Federal, Brasil

### Academics

Campina Grande Federal University

### Interests

- Software Engineering.
- Full Stack Software Development.
- Music.
- History.

### Development

- Front-end apps with React/Redux.
- Back-end apps with Node/Express.
- Mobile apps (Android/iOs).

### Projects

- CPC FaciLex - A new a easy way to learn and use the new Brazilian Civil Processual Code law.

### Profile Link

[Adriano Lemos](https://github.com/adriano-lemos-dev)
