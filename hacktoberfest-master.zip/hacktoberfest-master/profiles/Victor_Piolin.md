# Victor Piolin

### Location

Dijon/FRANCE

### Academics

Student at SUPINFO International Universtity

### Interests

- Love Bot's, Telegam / Messenger / Discord Bots.
- Open Source Projects

### Development

- Php Developper, JavaScript developper and new one in golang community.

### Projects

- [My Project](https://github.com/Vico1993/betaGoSeries) This day, I'm making a golang client to the Betaseries Api. (https://www.betaseries.com/api/). ( Still learning GO so.. )

### Profile Link

[Victor Piolin](https://github.com/Vico1993)