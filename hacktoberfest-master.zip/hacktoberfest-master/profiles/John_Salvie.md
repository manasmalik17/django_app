# John Salvie

### Location

Dallas, TX

### Academics

University of Oklahoma

### Interests

- lacrosse
- non-profits

### Development

- Mostly private repos for clients.

### Projects

- [HiddenWords](https://github.com/outofgamut/HiddenWords) Poetry and everyday objects

### Profile Link

[outofgamut](https://github.com/outofgamut)
