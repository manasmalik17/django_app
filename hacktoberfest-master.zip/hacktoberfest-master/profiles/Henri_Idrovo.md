# Henri idrovo

### Academics

Bachelors in Computer Engineering from the Illinois Institute of Technology. Go Illinois Tech!

### Interests

- All things Java
- All things AWS
- Open Source
- Coffee :-)

### Development

- Backend Java Engineer. Using Hadoop libraries. And AWS. 


### Projects

- check out my github: https://github.com/henriguy1210

### Profile Link

[Henri Idrovo](https://github.com/henriguy1210)
[Henri Idrovo](https://twitter.com/henriguy)