# Saideep Dicholkar

### Location

Mumbai, Maharashtra, India

### Academics

D.J. Sanghvi College of Engineering, Mumbai

### Interests

- Watching Tech related videos on YouTube
- Surfing the Internet
- Trying out different things in computing field

### Development

- Holographic Video Player
- Mumbai Tourism Website

### Projects

- [Holographic Video Player](https://github.com/saideepd/Holographic-Video-Player) A Holographic Video Player which enables users to view any video as a Holographic video which is projected on a glass pyramid
- [Mumbai Tourism](https://github.com/saideepd/Mumbai) A website for tourists traveling in Mumbai. This site will help you to find the popular destinations, history, hotels, etc. to visit in Mumbai.

### Profile Link

[Saideep Dicholkar](https://github.com/saideepd)