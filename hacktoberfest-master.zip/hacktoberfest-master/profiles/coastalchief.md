# coastalchief

### Location
Germany

### Academics
not really

### Interests
- [x] coding for fun
- [x] playing videogames for fun
- [x] sports

### Development
- [x] ruby for fun

### Projects
[Github Link](https://github.com/coastalchief)