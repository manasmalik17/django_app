# Avinash Jaiswal

## About me:

19 years old Young,Enthusiastic,Front-End developer and Programmer interested in backend development and eventually building some complex and really cool Web applications.

## Academics:

Presently pursuing my B.Tech in Computer Engineering from Sardar Vallabhai National Institute of Technology,Surat.

Completed my Class 12th from Sunbeam School Lahartara ,Varanasi.

## Languages Known:

- HTML
- CSS
- JAVASCRIPT
- JAVA
- C

## Framework used in Projects

- Twitter's Bootstrap

# [Check out my Github page](https://github.com/littlestar642)

# Email @: avinashjaiswal642@gmail.com