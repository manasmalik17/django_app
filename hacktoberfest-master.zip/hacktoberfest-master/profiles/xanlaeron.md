# xanlaeron

### Academics

-   Autodidact (Linux, Full Stack Development, Learning foreign languages)
-   Pharmacy Technician Graduate
-   Practical Nursing Graduate

### Interests

-   Mobile/Web Application Development
-   Product Development
-   Web Development
-   Creating icons
-   Kettlebells
-   Cooking/Baking

### Projects

-   scripts manager and mint cinnamon setup (Unfortunately, both projects are set to private for the time being as they both contain personal information. Making them public _**sans my personal info**_ is on my TODO list.)

### Profile Link

[xanlaeron](https://github.com/xanlaeron)
