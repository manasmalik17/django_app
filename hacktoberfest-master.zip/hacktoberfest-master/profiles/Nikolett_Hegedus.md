# Nikolett Hegedüs

### Location

Debrecen, Hungary

### Academics

University of Debrecen

### Interests

- coding
- databases
- music
- animals, nature

### Development

- PHP, Yii, Laravel, MySQL

### Projects

- [BMI calculator](https://github.com/henikolett/bmi-calc) BMI calculator in Angular2
- [Company Structure Registry](https://github.com/henikolett/company-structure-registry) Web application for managing company structure using Laravel framework

### Profile Link

[Nikolett Hegedüs](https://github.com/henikolett)