## Heidi Krcil

I am a nurse with a computer science degree. I work in the Health IT sector with electronic health records and clinical applications.

Enjoying exloring the joys of open source and getting back into coding. 

[me](https://github.com/hkrcil)


