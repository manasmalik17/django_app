# Akram Rameez

### Location

Bengaluru, India

### Academics

National Institute of Technology, Karnataka

### Interests

- Playing football.
- I'm currently learning MMA.
- Trying to approach higher education with a concerned smile .

### Development

- React is the story of my life right now.
- React is the story of my life right now.

### Projects

- None right now. Although I do work a lot on [react-virtualized](https://github.com/bvaughn/react-virtualized) and [recharts](https://github.com/recharts/recharts) at the moment.

### Profile Link

[Akram Rameez](https://github.com/akram-rameez)