# Brian (Bashbers)

### Location

The Netherlands

### Academics

Avans Academics of Applied Sciences

### Interests

- Gaming
- Programming in new (and weird) languages
- Jiu Jitsu

### Development

- Scholar

### Projects

- None as of yet. :(

### Profile Link

[Bashbers](https://github.com/Bashbers)
