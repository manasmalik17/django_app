# Your Name

Furkan Arabaci

### Location

Bursa/Turkey

### Academics

Sakarya University

### Interests

Technology, programming, machine learning. augmented reality

### Development

- Inventor of the My Pillow

### Profile Link

[Furkan Arabaci](https://github.com/illegaldisease)