![Schitte Industries](https://schitte.github.io/Logo.png)

### About

- [Main Website](https://sites.google.com/view/schitteindustries)
- [Fun Products](https://sites.google.com/view/schitteindustries/schitte-products)

### Connect

- [Send us feedback/suggestions](https://sites.google.com/view/schitteindustries/feedback-suggestions)
- [Hang out with us on Discord](https://discordapp.com/channels/274387509109325825/)
- [See exclusive contents on Patreon](https://www.patreon.com/schitte)

### Github Profile

- [Schitte Industries](https://github.com/schitte)
