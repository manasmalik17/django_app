# Pablo Andrés Dorado Suárez

### Location

Bogotá, Colombia

### Academics

Systems Engineering, Universidad Nacional de Colombia '20

### Interests

- Development
- Photography
- Bicycle Riding
- Swimming

### Development

- Created [bool.js](https://bool.js.org), making APIs great again since 2015.
- Currently working in AI research.

### Projects

- [Bool.js](https://github.com/booljs) MVC framework to make APIs.

### Profile Link

[@pandres95](https://github.com/pandres95)
