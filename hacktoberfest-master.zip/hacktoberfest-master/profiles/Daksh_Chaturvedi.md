# Daksh Chaturvedi

### Location

New Delhi/ India

### Academics

IIIT Delhi

### Interests

- Music
- Reading
- Maths

### Development

- Stick for visually aided
- Safe path detection for visually aided
- Traffic density estimation

### Profile Link

[Daksh Chaturvedi](https://github.com/daksh249)
