# Haley Smith

### Location

Orlando, Florida / Travelling

### Academics

B.S. in Digital Arts & Design

### Interests

- UX/UI
- Interactive Design
- Foreign Languages
- Cute Dogs

### Projects

- Luxury travel site
- personal website

### Profile Link

[Haley Smith](https://github.com/haleycs)
