# Mintoo Kumar

### Location

New Delhi, India

### Academics

NSIT, New Delhi.

### Interests

Machine learning, Android App development, Data structures and Algorithms 

### Profile Link

[mintoo511](https://github.com/mintoo511)
