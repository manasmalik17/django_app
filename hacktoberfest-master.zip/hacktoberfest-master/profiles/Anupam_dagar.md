# Anupam Dagar

### Location

India

### Academics

Indian Institute of Information Technology Allahabad (IIIT Allahabad)

### Interests

- Counter Strike
- Movies
- Contributing to open source projects

### Development

- Full stack developer and competitive coder.

### Projects

- [HoxNox - Portfolios Made Easy](https://github.com/Anupam-dagar/Portfolio-Generator) HoxNox is a simple 3 step portfolio generator built using Django.

### Profile Link

[Anupam Dagar](https://github.com/Anupam-dagar)
