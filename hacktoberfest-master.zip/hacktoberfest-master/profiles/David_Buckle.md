# David Buckle

### Location

Manchester/UK

### Interests

Linux
Gaming
Security

### Profile Link

[met3or](https://github.com/met3or)
