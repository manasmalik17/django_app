# Gaurav Lalchandani

### Academics

Motilal Nehru National Institute of Technology, Allahabad

### Interests

- Coding
- Songs 
- Cartoons :P

### Development

- Mostly build softwares (Python or Java)
- Recently started Genetic Programming, working for building NN

### Projects

- [noteCV](https://github.com/return007/noteCV) - Interactive note taking software, based on Computer Vision

### Profile Link

[return007](https://github.com/return007)
