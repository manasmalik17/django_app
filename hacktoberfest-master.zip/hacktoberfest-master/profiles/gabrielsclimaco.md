# Gabriel de Souza Clímaco

### Location

Brasilia, Brazil

### Academics

Software Engineering, Universidade de Brasilia

### Interests

- Javascript
- Web development
- Mobile development
- Movies
- League of Legends

### Development

- Javascript bitch
- Full stack developer
- Mobile developer (React Native, Java android, Quasar)

### Projects

- Most of them are private, but pretty much sums up in Vue.js as frontend and Node.js as Backend
- You can see other projects on my profile bellow

### Profile Link

[gabrielsclimaco](https://github.com/gabrielsclimaco)
