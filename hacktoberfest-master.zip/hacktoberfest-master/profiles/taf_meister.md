# Your Name
Taf Meister

### Academics
NYU

### Interests
- Raspberry Pi, DYI Projects

### Development
- Open Source

### Projects
- [SQL-EAN Boilerplate](https://github.com/tashrafy/generator-sql-fullstack) Boilerplate replacing the M (MongoDB) in MEAN stack with SQL (Sequelize) 

### Profile Link
[Taf Meister](https://github.com/tashrafy)