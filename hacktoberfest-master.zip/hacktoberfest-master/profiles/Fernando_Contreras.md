# Fernando Contreras

### Location

Nuevo Leon, Mexico

### Academics

Universidad Autonoma de Nuevo Leon

### Interests

- Breakdance, House dance and Popping
- Javascript
- Cats

### Development

- Software Engineer

### Projects

- [DRFNestedSerializers](https://github.com/fercreek/DRFNestedSerializers) Django Rest Framework Nested Serializer for Django

### Profile Link

[Fernando Contreras](https://github.com/fercreek/)