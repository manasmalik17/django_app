# Name
Aswin M Guptha
### Academics
BTech CSE from [Amrita University](https://www.amrita.edu)
### Projects
[My Projects](https://www.github.com/aswinmguptha)
Links to my projects
### Profile Link
[GitHub](https://github.com/aswinmguptha)
[GitLab](https://gitlab.com/aswinmguptha)
[Twitter](https://twitter.com/aswinmguptha)

