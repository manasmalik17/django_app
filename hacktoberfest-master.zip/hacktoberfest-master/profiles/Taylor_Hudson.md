# Taylor Hudson 

### Location

Allen, Texas, USA

### Academics

Allen High School
Greenville High School
Texas A&M - Commerce

### Interests

- Reading
- Coding
- DevCon
- Problem Solving
- Puzzles
- (Some)Games
- Mathematics

### Development

- CoDeveloper of TLK Super Tanvir Dance Party @OnContentStop @WestonReed
- Many many others

### Projects

- May Update Later

### Profile Link

[AllenCompSci](https://github.com/AllenCompSci)
