# Rajeev Kumar Singh

### Location

Gandhinagar, Gujrat, India

### Academics

Undergraduate in B.Tech (Information Technology) from IIIT Vadodara College

### Interests

- User Interface and User Experience
- Javas-Based Technologies
- Memes
- I LOVE TRAVELLING

### Development

- Java Developer, Android Developer

### Projects

- https://github.com/rajeeviiit/AndroidProject/tree/master/Bims-KitchenAdminApp Admin App for Night Kitchen
- https://github.com/rajeeviiit/AndroidProject/tree/master/MyApplication Instagram type app

### Profile Link

[rajeeviiit] https://github.com/rajeeviiit