
# Bharath

### Location

India

### Academics

Computer Science & Engineering

### Interests

- Programming, Computers
- Chess, Cricket
- Cosmology

### Development

- Front End Developer

### Projects

- [Tic Tac Toe](https://github.com/iambk/tic-tac-toe) Tic Tac Toe game with multiplayer options and two different difficulty levels.
- [Simon Game](https://github.com/iambk/simon-game) Simon Game is an electronic game of memory skill. The device creates a series of tones and lights and requires a user to repeat the series. If the user succeeds the series becomes progressively longer and more complex. Once the user fails, the game is over.

### Profile Link

[Bharath Kumar](https://github.com/iambk)