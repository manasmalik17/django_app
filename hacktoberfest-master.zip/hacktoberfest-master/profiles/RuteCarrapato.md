# Rute Carrapato

### Location

Lisbon, Portugal

### Academics

<Academia de Código_>, Portugal

### Interests

- Games 

### Development

- Java Development

### Projects

- Still learning to create my first project

### Profile Link

[Rute Carrapato](https://github.com/RuteCarrapato)
