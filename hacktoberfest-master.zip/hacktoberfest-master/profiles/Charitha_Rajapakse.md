# Charitha Rajapakse

## About Me

I'm a Software Engineering Student at University of Westminister. I'm from Sri lanka. I'm 21 years old. I'm interested in AI, Big Data Analytics.

##Languages which I know

- Java
- C++
- Java Script
- HTML
- CSS

## Frameworks and Technologies which I know:

- jQuery
- Node.js
- MongoDB
- Android Studio


### Interests

- Singing
- Art
- Collecting Stamps

### Profile Link
[Charitha Rajapakse](https://github.com/Charitha96)
