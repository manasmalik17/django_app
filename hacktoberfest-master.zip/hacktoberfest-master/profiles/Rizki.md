# Rizki Ramadhana

### Location

Yogyakarta/Indonesia

### Academics

Gadjah Mada University

### Interests

- Code
- Game

### Development

- Web Developer

### Projects

- [GMAE](https://github.com/rizkiprof/GMAE-UGM-Gadjah-Mada-Agro-Expo) Website for Agriculture Expo Event

### Profile Link

[Rizki](https://github.com/rizkiprof)
