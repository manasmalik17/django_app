#Justin Rice
#Boston, MA 

#Current Works
- Dev/DevOps

#Academics
- Kent State Univeristy
- UNH

#Interests
- JS (ALL OF THEM)
- AWS
- Internet Security and Hacking
- Cool APIs

#Hobbies
- Programming / Craft Beer
#Social
Github: https://github.com/jsrice7391
LinkedIn: https://www.linkedin.com/in/justinrice1/



