# Galen Nare

### Location
Newark, DE, USA

### Education
Junior in High School.
I plan to go to the University of Delaware and major in Mechanical Engineering.

### Languages known
- Java
- Python 2.7
- HTML5
- C#
- Arduino C

### Projects
- Android app for the Congressional App Challenge
- School CS projects
- A Minecraft Mod (slowly working)

### Links
[VoxelBuster](https://github.com/VoxelBuster)
[My Site](https://voxelbuster.github.io/)

### Contact info
Email: voxelbustergaming@gmail.com
Discord: VoxelBuster#3318