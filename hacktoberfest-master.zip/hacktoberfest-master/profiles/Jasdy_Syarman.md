# Jasdy Syarman Mohd Saari

### Academics

- University Technology, Malaysia

### Interests

- Web Development 
- IoT

### Projects

- https://rakanmet.met.gov.my

### Profile Link

[akutaktau](https://github.com/akutaktau)
