# Civitas07

### Location

Australia

### Academics

Edith Cowan University

### Interests

- Knitting
- Reading
- Hiking
- Maths
- Spanish

### Development

- Certificate Website Repository
- Library Database

### Profile Link

[Civitas07](https://github.com/civitas07)
