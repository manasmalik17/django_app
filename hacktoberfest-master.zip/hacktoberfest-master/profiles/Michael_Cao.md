# Michael Cao

### Academics

Franklin Regional Senior High School

### Interests

- FIRST Robotics Competition

### Development

- I make a lot of Discord bots!
- I code real life robots!
- I do a lot of personal stuff too to learn more programming.

### Projects

- [RoBot](https://github.com/FRCDiscord/RoBot) - The Discord Bot I work on the most

### Profile Link

[Michael Cao](https://github.com/mcao)
