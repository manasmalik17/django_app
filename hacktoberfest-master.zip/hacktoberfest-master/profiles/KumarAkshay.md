# Kumar Akshay

### Location

Indore, India

### Academics

I'm a student persuing B.E at SGSITS.

### Interests

- I like reading about Machine Learning.

### Development

- I'm ML developer.
- Open source contributer at Plone.

### Projects

- [Handwritten digits recognizer](https://github.com/kakshay21/ML-tensorflow) Implemented multilayered neural network to recognize handwritten digits with the best accuracy of 99.25%.

- [AAYAAM](https://github.com/kakshay21/AAYAM) 

### Profile Link

[kakshay21](https://github.com/kakshay21)  Organized Fox Hunter, a treasure hunt competition.

