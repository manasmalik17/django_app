# Your Name

### Location

Bandung/Indonesia

### Academics

Your School

### Interests

- Technology, Design, Coffee, Mountaineer

### Development

- Web development

### Profile Link

[Egi Nugraha](https://github.com/eginugraha)