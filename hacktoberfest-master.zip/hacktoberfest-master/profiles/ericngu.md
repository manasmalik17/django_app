# Eric Ngu

### Location

Kuala Lumpur, Malaysia

### Academics

BSc Computer Science at Sunway University

### Interests

- FPS Shooters
- Messing around with my computer
- Non-fiction books

### Profile Link

[Eric Ngu](https://github.com/ericngu)
