# Danny Mitchell

### Location

Kansas City, MO USA

### Academics

University of Missouri - Kansas City

### Interests

- Brewing Beer
- Playing Guitar
- Vegan Food
- Video Games

### Development

Learning mostly in .Net
I want to work in music recommender systems.

### Profile Link

[Daniel Mitchell](https://github.com/Danny_Danielsan)
