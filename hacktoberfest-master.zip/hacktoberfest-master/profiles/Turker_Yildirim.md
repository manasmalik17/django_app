Türker Yıldırım

### Location

Tekirdağ/Turkey

### Academics

University of Namık Kemal

### Interests

- Video Games, Sci-Fi,

### Development

- Python lover for now, maybe will be interested in another languages in the future.

### Projects

- [django-skeleton-with-custom-user](https://github.com/turkerdotpy/django-skeleton-with-custom-user) Skeleton for Django projects. Bonus Accounts App for custom user.

### Profile Link

[turkerdotpy](https://github.com/turkerdotpy)
