# Anthony Vingas

### Academics

DEC - Digital Filmmaking

### Interests

- Make music, web dev, filmmaking

### Development

- Learning Web Dev currently

### Projects

- [Nothing to see here](https://github.com/avingas) No projects yet! :(

### Profile Link

[avingas](https://github.com/avingas)
