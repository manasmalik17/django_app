# Kevin Yang

### Location

San Francisco

### Academics

Waterloo

### Profile Link

[k-yang](https://github.com/k-yang)
