Location

Florianopolis, SC, Brazil

Academics

Graduation in progress, analysis and development of systems.

Interests

HTML
CSS
TS
JAVA
Games!

Projects

Project in progress, software with big data.