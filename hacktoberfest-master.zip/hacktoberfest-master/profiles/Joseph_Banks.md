# Joseph Banks

## Interests
- Python
- Elixir
- Backend-web technology

## Want to learn
- Front end
- React
- More Node.js

## Links

[Twitter](https://twitter.com/JosephTehDev)

[GitHub](https://github.com/JoeBanks13/)

[GitLab (more updated)](https://gitlab.josephbanks.me/JoeBanks13)

[WebPage (hype)](https://josephbanks.me)
