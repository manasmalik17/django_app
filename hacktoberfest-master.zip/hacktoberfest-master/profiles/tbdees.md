# tbdees

### Location

Laguna Beach, CA
occasionally in NY, FL, CO

### Academics

B. S. Computer Science
B. A. Studio Art
MBA

### Interests

- finance
- python
- snowboarding

### Development

- full stack project manager before full stack was a thing
- financial software consultant


### Profile Link

[tbdees](https://github.com/tbdees)
