# Christopher Zentgraf

### Location

Munich, Germany

### Academics

University of Applied Sciences Rosenheim, Germany

### Interests

- Automation
- Docker
- Kubernetes
- DevOps

### Development

- Creator of CI/CD pipelines

### Projects

- [BSGClock](https://github.com/TheZenti/BSGClock) A replica of the countdown timer seen in Battlestar Galactica, S01E01.

### Profile Link

[TheZenti](https://github.com/TheZenti)
