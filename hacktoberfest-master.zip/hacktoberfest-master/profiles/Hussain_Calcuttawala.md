# Hussain Calcuttawala

### Location

Bengaluru, India

### Academics

SRM University, Chennai

### Interests

Hackathons , coding , reading

### Development

Accio : An android application to view academic details of SRM University students.

### Projects

- [MapMyLocationEminent](https://github.com/hussainbadri21/MapMyLocationEminent)
For real time location tracking using google maps

### Profile Link

[hussainbadri21](https://github.com/hussainbadri21)
