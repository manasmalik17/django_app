# SYAMKUMAR

### Location

ERNAKULAM,KERALA, INDIA

### Academics

Undergraduate in Computer Science from Mar Baselios Institute of Technology and Science

### Interests

- Web development
- Android
- Machine Learning
- Gaming


### Development

- Wb devoleper
- Data science


### Profile Link

facebook: https://www.facebook.com/syamkumar3526
github: [syamkumar] https://github.com/syam3526
website: syamkumar.xyz
