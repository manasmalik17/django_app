# Omid Nikrah

### Location

Tehran, Tehran, Iran

### Interests

- Programming
- Game
- Swimming

### Projects

- [React Github](https://github.com/omidnikrah/react-github) A simple react version of Github

### Profile Link

[Omid Nikrah](https://github.com/omidnikrah)
