# Matei DAvid

### Birmingham, United Kingdom

### University of Birmingham, UK
---

### Interests

- Coding, Software Development & anything geeky! <3
- Besides being a geek, I also like sports, loads of music and I run on coffee


### Profile Link
[Matei David](https://github.com/Matei207)
