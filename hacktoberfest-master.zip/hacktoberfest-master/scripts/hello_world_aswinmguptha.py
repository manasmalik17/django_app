# Language: Python
# AUTHOR: Aswin M Guptha
# GitHub: https://www.github.com/aswinmguptha

#!/usr/bin/python2.7

print "Hello, World"
