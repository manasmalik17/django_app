// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Luis Jaquez
// GITHUB: https://github.com/LuisJaquez

console.log('Hello World!');