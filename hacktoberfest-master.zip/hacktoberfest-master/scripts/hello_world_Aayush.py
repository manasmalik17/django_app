# LANGUAGE: Python
# ENV: Python3.5
# AUTHOR: Aayush N
# GITHUB: https://github.com/Aayush-N

def hello_world():
	print('Hello, World!')

hello_world()
