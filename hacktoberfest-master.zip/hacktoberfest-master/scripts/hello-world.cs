// LANGUAGE: c#
// ENV: Geany
// AUTHOR: Ethan L
// GITHUB: https://github.com/athenafromage

using System;
using static System.Console;

namespace hello-world
{
    class hello-world
    {
        static void Main()
        {
            Write("Hello, World!");
        }
    }
 }
        
