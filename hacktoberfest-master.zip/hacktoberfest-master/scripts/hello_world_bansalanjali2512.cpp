// LANGUAGE: C++
// AUTHOR: Anjali Bansal
// GITHUB: https://github.com/bansalanjali2512

#include <iostream>
using namespace std;

int main() {
	cout << "Hello World..!" << endl;
	return 0;
}
