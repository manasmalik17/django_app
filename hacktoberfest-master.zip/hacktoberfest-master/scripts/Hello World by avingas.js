// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Anthony Vingas
// GITHUB: https://github.com/avingas

console.log("Hello World") 
