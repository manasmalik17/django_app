//Language: C++
//ENV: C9
//AUTHOR: Matthew Dray
//GITHUB: https://github.com/17robots

#include <iostream>

int main() {
    std::cout << "Hello World\n";
    return 0;
}
