#!/bin/zsh
echo "Hello, World!"
