// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Arjun Rajpal
// GITHUB: https://github.com/arjunrajpal

console.log('Hello, World!');