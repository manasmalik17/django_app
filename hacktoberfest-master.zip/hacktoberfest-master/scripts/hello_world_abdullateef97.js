// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Abdullateef
// GITHUB: https://github.com/abdullateef97

console.log('Hello, World!');