// LANGUAGE: C
// ENV:
// AUTHOR: Gustavo Ziaugra
// GITHUB: https://github.com/GustavoZiaugra

#include stdio.h

int main (void) {
  prinf("Hello World\n");
}
