# LANGUAGE: Elixir
# AUTHOR: Fernando Contreras
# GITHUB: https://github.com/fercreek

defmodule HelloWorld do
  def hello do
    IO.puts "Hello World!"
  end
end
