# LANGUAGE: Python
# ENV: Python3.5
# AUTHOR: Artur Baruchi
# GITHUB: https://github.com/abaruchi

a = "Hello"
b = "World"
print("{} {}".format(a, b))
