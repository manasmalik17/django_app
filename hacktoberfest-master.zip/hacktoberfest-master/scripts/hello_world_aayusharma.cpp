
// LANGUAGE: C++
// ENV: GCC
// AUTHOR: Aayush Sharma
// GITHUB: https://github.com/aayusharma

#include <bits/stdc++.h>
using namespace std;
int main()
{
    cout<<"Hello World"<<endl;
}