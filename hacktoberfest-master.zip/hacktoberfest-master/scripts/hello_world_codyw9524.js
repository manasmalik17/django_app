// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Cody Williams
// GITHUB: https://github.com/codyw9524
function helloWorld(){
	const str = 'Hello World!';
	for (let char of str) {
		console.log(char);
	}
}

helloWorld();
