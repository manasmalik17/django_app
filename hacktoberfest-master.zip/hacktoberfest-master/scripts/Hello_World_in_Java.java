//Language : Java
// Author : Satyarth6022
//GitHUb Profile: https://github.com/Satyarth6022


public class GitHub_Hacktoberfest{
	
		public static void main(String[] args){
			System.out.println("Hello, World!");
		}
}