# LANGUAGE: Python
# ENV: Python
# AUTHOR: Ankit Chhetri
# GITHUB: https://github.com/ankitch

print ("Namaste World!")
