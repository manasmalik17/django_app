//Language : Java
//Author : Gulzar Ahmed
//GitHUb Profile: https://github.com/gulzar1996


public classHacktoberfest{
	public static void main(String[] args){
			System.out.println("Hello, World!");
		}
}
