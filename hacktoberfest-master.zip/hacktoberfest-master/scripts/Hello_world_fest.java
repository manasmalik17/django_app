/*
Author: Meghna
Language : Java
Github profile : ttps://github.com/meghnatolani
*/

public class Hello_world_fest{
	public static void main(String[] args){
		System.out.println("Welcome to the HacktoberFest 2017");
	}
}
