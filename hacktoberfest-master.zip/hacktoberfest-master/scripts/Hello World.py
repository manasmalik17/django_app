#Lang Python2
#env Interactive as well as script
#aut Anshu Musaddi
#github https://github.com/anshucollege
print "Hello World"
print "Kevin was here to Say Hello World!"
