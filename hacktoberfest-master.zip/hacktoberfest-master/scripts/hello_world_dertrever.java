/**
  LANGUAGE: JAVA
  AUTHOR: dertrever
  GITHUB: https://github.com/dertrever
*/

public class hello_world {

    public static void main(String[] args) {
    
        System.out.println("Hello, world!");
        
    }

}
