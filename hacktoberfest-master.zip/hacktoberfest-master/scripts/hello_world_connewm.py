# Language: Python
# Env: Python3.5
# Author: Connor Newman
#:GitHub: https://github.com/connewm

print("Hello World")
