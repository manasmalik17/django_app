//Language: C++  
//AUTHOR: Anupam Dagar  
//GITHUB: https://github.com/Anupam-dagar  

#include<stdio.h>  
int main()  
{  
  cout << "Hello World!" << endl;  
  return 0;  
}  
