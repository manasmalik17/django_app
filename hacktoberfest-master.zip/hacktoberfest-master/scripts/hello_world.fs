// LANGUAGE: F#
// AUTHOR: coastalchief
// GITHUB: https://github.com/coastalchief

printfn "Hello World"