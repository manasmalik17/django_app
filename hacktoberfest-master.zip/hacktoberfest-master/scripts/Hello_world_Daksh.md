// LANGUAGE:Python
// AUTHOR: Daksh Chaturvedi
// GITHUB: https://github.com/daksh249
print("Hello world")
