-- LANGUAGE: elm
-- ENV: elm
-- AUTHOR: Abhishek Nair
-- GITHUB: https://github.com/abhishek1nair

module Hello exposing (..)

import Html exposing (text)

main =
    text "Hello World!"
