# LANGUAGE: Python
# AUTHOR:   Akash Goel
# GITHUB:   https://github.com/akashgoel1197

print("Hello, World!");
# The print function is used here to print whatever has been placed inside the brackets.
# The inverted commas tell the compiler that the given item is a string.
