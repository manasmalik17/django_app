//LANGUAGE: C
//ENV: GCC
//AUTHOR: RASHMI NAGPAL
//GITHUB: https://github.com//AliceWonderland
#include <stdio.h>
int main(){
	printf("Hello, World!");
	return 0;
}
