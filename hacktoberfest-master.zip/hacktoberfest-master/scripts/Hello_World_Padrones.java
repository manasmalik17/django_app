/*
 * LANGUAGE: JAVA
 * AUTHOR: Gelle Padrones
 * GITHUB: https://github.com/aegelle31
 * 
 * **/
// this is first program everyone should start from..
public class HelloWorldPadrones {

	public static void main(String[] args) {
		
		System.out.println("Hello World");

	}

}
