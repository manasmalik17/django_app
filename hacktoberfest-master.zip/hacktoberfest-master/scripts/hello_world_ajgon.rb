#!/usr/bin/env ruby

puts 'Hello World!'
