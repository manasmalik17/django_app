/*Lang C++
env script
aut Anshu Musaddi
github https://github.com/anshucollege*/
#include<iostream.h>
int main()
{
  cout<<" Hello World ";
}
