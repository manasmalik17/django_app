// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Tyler Williams
// GITHUB: https://github.com/Tyler-Williams

console.log('Hello, World!');
