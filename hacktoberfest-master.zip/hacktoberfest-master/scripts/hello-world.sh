#!/usr/bin/env bash
# LANGUAGE: Bash
# AUTHOR: Matt Gabriel
# GITHUB: https://github.com/xanlaeron

echo "Hello World and Hello $USER!"
