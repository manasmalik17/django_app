// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Joey Marshment-Howell
// GITHUB: https://github.com/josephkmh

console.log('Hello, world!');
