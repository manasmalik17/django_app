# LANGUAGE: Python
# AUTHOR: BrunoSXS
# GITHUB: https://github.com/brunosxs

#!/usr/bin/python3

print ("Hello, World!")
