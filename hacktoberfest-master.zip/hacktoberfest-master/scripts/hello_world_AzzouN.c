// LANGUAGE: C
// AUTHOR: Azzeddine NACER
// GITHUB: https://github.com/AzzouN
#include <stdio.h>
#include <stdlib.h>

int main(int argc, char const *argv[]) {
    printf("Hello, World!");
    return 0;
}
