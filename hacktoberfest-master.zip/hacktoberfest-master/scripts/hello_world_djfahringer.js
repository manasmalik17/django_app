// LANGUAGE: Javascript
// ENV: Node.js
// AUTHOR: Dylan Fahringer
// GITHUB: https://github.com/djfahringer

console.log('Hello, World!');
