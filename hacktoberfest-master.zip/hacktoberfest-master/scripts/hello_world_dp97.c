// LANGUAGE: C
// AUTHOR: Petrov Dumitru
// GITHUB: https://github.com/dp97

int     main() {
      printf("Hello, World!");
      return 0;
}
