// Author: Tara Boyle
// GitHub: https://github.com/tboyle621
// Language: Java

public class HelloWorldJava {
  public static void main() {
    System.out.println("Hello world!");
  }
}
