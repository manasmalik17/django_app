# LANGUAGE: Python
# ENV: Idle
# AUTHOR: Francesco d'Amato
# GITHUB: https://github.com/EricBonham

for i in str("hello world!"):
    print(i, end='')
    
