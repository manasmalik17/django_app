(* LANGUAGE: Ocaml
 * AUTHOR: Aditya Kabra
 * GITHUB: https://github.com/adi0602
 *)
 
    print_string "Hello world!\n";;
